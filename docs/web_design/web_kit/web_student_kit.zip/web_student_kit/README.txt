Web design student kit - Year 10 Multimedia

Each numbered folder is the starting point for one tutorial:
  01_first_page      Your first web page
  02_links_images    Links and images
  03_lists_tables    Lists, tables and media
  04_css_basics      CSS basics
  05_box_model       The box model (profile cards)
  06_layout          Semantic HTML and flexbox
  07_responsive      Responsive design
  08_javascript      Dark mode and gallery
portfolio_template   Four linked pages to start your assessment (make it your own!)
testing_table.pdf    Print for your assessment testing

Open a folder in VS Code with File > Open Folder.
