// Dark mode tutorial
// 1. Find the button with document.querySelector
// 2. Write a function that toggles the "dark" class on document.body
// 3. Add a click event listener to the button
