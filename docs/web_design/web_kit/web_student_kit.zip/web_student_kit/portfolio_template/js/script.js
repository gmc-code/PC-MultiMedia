// Dark mode button
const themeButton = document.querySelector("#theme-button");

function toggleTheme() {
  document.body.classList.toggle("dark");

  if (document.body.classList.contains("dark")) {
    themeButton.textContent = "Light mode";
  } else {
    themeButton.textContent = "Dark mode";
  }
}

themeButton.addEventListener("click", toggleTheme);
