CORAL REEF STUDENT KIT
======================

index.html          Double-click this to see your scene in a web browser.
my_scene.js         The list of your GIFs. This is the only file you change.
gifs/               Save the GIFs you make in Photoshop here.
images/             The background picture.
photoshop_frames/   Ready-made frames to turn into GIFs in Photoshop.
                      Pictures that stay put: seahorse, pufferfish, octopus, eel, anemone,
                      treasure_chest, starfish
                      Pictures that travel: submarine, shark, jellyfish, fish_school,
                      turtle, clownfish, hermit_crab
                      Small GIFs to spawn: bubble, coin.
engine/             The code that makes the scene work. Do not change it.

Follow the tutorial "Make a clickable coral reef" to get started.
