// ============================================================
//  MY CORAL REEF
//  This is the only file you need to change.
//  Change the words and numbers. Keep the commas, the brackets
//  and the "speech marks" exactly where they are!
// ============================================================

const sceneTitle = "My coral reef";
const sceneBackground = "images/background.png";
const sceneTheme = "reef";

// One line for each GIF in your gifs folder.
//   file    = the file name of the GIF (spelt exactly the same)
//   name    = what the picture is called
//   x       = how far across it is (0 = left edge, 100 = right edge)
//   y       = how far down it is   (0 = top edge, 100 = bottom edge)
//   width   = how big it is (10 = one tenth of the width of the background)
//   seconds = how long it plays after a click (number of frames x delay)
//   move    = makes it travel (optional). seconds is then how long the trip takes.
//             "left" or "right"            straight across
//             "up" or "down"               straight up or down
//             "wave-left" or "wave-right"  bobbing up and down as it goes
//             "hop-left" or "hop-right"    bouncing along
//             "jump"                       leaps up and lands where it started
//   spawn   = another GIF that comes out of it when it plays (optional), e.g. "note.gif"
//   count   = how many copies come out (5 if left out, up to 20)
//   spread  = how the copies move: "burst", "up", "down", "fountain" or "trail"
//   spawnWidth = how big the copies are (optional, like width). "2-5" gives random sizes.
//   every   = copies come out one at a time, this many seconds apart (optional)
//   spawnFor = how many seconds the copies keep coming (optional)
//   life    = how many seconds each copy takes to finish (optional)
//   distance = how far each copy goes, as a percentage of the scene (optional)

const myGifs = [
  { file: "example_clownfish.gif", name: "Clownfish", x: 20, y: 55, width: 8, seconds: 9, move: "wave-right" },
];

// Extras.
// sceneEffect can be "bubbles", "confetti" or "snow".
// startEffect = true turns it on when the page opens (it always comes on at the end).
const sceneEffect = "bubbles";
const startEffect = false;
const playSound = true;

// "once" plays the GIF one time for each click.
// "toggle" means click to start and click again to stop.
// "hover" plays while the mouse is over the picture.
const playMode = "once";

const finishIcon = "🐠";
const finishMessage = "You found them all. What a reef!";
