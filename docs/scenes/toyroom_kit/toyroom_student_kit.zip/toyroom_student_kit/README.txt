TOY ROOM STUDENT KIT
====================

index.html          Double-click this to see your scene in a web browser.
my_scene.js         The list of your GIFs. This is the only file you change.
gifs/               Save the GIFs you make in Photoshop here.
images/             The background picture.
photoshop_frames/   Ready-made frames to turn into GIFs in Photoshop.
                      Pictures that stay put: yo_yo, jack_in_box, blocks, rocking_horse,
                      teddy, spinning_top, drum
                      Pictures that travel: paper_plane, rocket, robot, ball, train, frog,
                      toy_car
                      Small GIFs to spawn: sparkle, note, heart.
engine/             The code that makes the scene work. Do not change it.

Follow the tutorial "Make a clickable toy room" to get started.
