BEACH SCENE STUDENT KIT
=======================

index.html          Double-click this to see your scene in a web browser.
my_scene.js         The list of your GIFs. This is the only file you change.
gifs/               Save the GIFs you make in Photoshop here.
images/             The background picture.
photoshop_frames/   Ready-made frames to turn into GIFs in Photoshop.
                      Pictures that stay put: sun, flag, umbrella, sandcastle, esky.
                      Pictures that travel: crab, cloud, seagull, sailboat, surfer,
                      kangaroo, beach_ball, dolphin.
                      Small GIFs to spawn: drop, sparkle.
engine/             The code that makes the scene work. Do not change it.

Follow the tutorial "Make a clickable beach scene" to get started.
