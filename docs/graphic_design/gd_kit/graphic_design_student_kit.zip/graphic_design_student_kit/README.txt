Graphic design student kit - Year 10 Multimedia

riverbend_brand/  logo, brand guide and garden illustration for the made-up client
templates/        guide overlays for square, portrait and Story sizes; phone mock-up (frame + screen shape)
social_media_planning_sheet.pdf  print for your assessment

Phone mock-up: put phone_screen_shape.png on a layer, place your post above it and choose
Create Clipping Mask, then put phone_frame.png on top.
